# RAG System with Ollama, LangChain, and PostgreSQL Vector Database

This project implements a Retrieval Augmented Generation (RAG) system using Ollama for the language model, LangChain for the framework, and PostgreSQL with pgvector for vector storage.

## Prerequisites

1. PostgreSQL installed on your system
2. Ollama installed with llama2:3b model
3. Python 3.8+

## Setup Instructions

1. Install PostgreSQL and enable pgvector:
```sql
CREATE EXTENSION vector;
```

2. Create a new database:
```sql
CREATE DATABASE vectordb;
```

3. Install Python dependencies:
```bash
pip install -r requirements.txt
```

4. Update the database connection string in `rag_system.py` if needed:
```python
CONNECTION_STRING = "postgresql+psycopg2://postgres:postgres@localhost:5432/vectordb"
```

## Usage

Run the example script:
```bash
python rag_system.py
```

The script includes example usage with sample documents. You can modify the `main()` function to:
- Add your own documents
- Query the system with different questions
- Customize chunk sizes and overlap for document splitting

## Features

- Document ingestion with automatic chunking
- Vector embedding using Ollama
- Efficient vector similarity search with pgvector
- Conversational memory for context-aware responses
- Easy-to-use API for adding documents and querying

## Architecture

1. Document Processing:
   - Documents are split into chunks
   - Each chunk is embedded using Ollama embeddings

2. Storage:
   - Embeddings are stored in PostgreSQL using pgvector
   - Efficient similarity search using vector operations

3. Query Processing:
   - Questions are embedded using the same model
   - Similar documents are retrieved
   - LLM generates responses using retrieved context