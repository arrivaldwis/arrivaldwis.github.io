import os
from typing import List
from dotenv import load_dotenv
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.llms import Ollama
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores.pgvector import PGVector
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain.docstore.document import Document
from langchain.prompts import PromptTemplate

# Load environment variables
load_dotenv()

# Database configuration
CONNECTION_STRING = "postgresql+psycopg2://postgres:postgres@localhost:5432/vectordb"
COLLECTION_NAME = "document_chunks"

# Custom prompt template
custom_template = """Use the following pieces of context to answer the question at the end. 
If you don't know the answer, just say that you don't know, don't try to make up an answer.

Context:
{context}

Question: {question}

Please provide a detailed and helpful answer based on the context above:"""

CUSTOM_PROMPT = PromptTemplate(
    template=custom_template, input_variables=["context", "question"]
)

class RAGSystem:
    def __init__(self):
        # Initialize Ollama with llama3.2:1b
        self.embeddings = OllamaEmbeddings(model="llama3.2:1b")
        self.llm = Ollama(model="llama3.2:1b")
        
        # Initialize vector store
        self.vector_store = PGVector(
            connection_string=CONNECTION_STRING,
            collection_name=COLLECTION_NAME,
            embedding_function=self.embeddings,
        )
        
        # Initialize conversation memory
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True
        )
        
        # Initialize retrieval chain with custom prompt
        self.qa_chain = ConversationalRetrievalChain.from_llm(
            llm=self.llm,
            retriever=self.vector_store.as_retriever(
                search_kwargs={"k": 3}  # Retrieve top 3 most relevant chunks
            ),
            memory=self.memory,
            verbose=True,
            combine_docs_chain_kwargs={"prompt": CUSTOM_PROMPT}
        )

    def add_documents(self, texts: List[str], chunk_size: int = 1000, chunk_overlap: int = 200):
        """
        Add documents to the vector store
        """
        # Create text splitter
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap
        )
        
        # Create documents
        documents = [Document(page_content=text) for text in texts]
        
        # Split documents into chunks
        splits = text_splitter.split_documents(documents)
        
        # Add to vector store
        self.vector_store.add_documents(splits)
        
        return len(splits)

    def query(self, question: str) -> str:
        """
        Query the RAG system
        """
        response = self.qa_chain({"question": question})
        return response["answer"]

def main():
    # Initialize RAG system
    rag = RAGSystem()
    
    # Example usage
    # Add some sample documents
    sample_texts = [
        "LangChain is a framework for developing applications powered by language models. " 
        "It provides tools and abstractions for working with LLMs, including prompt management, "
        "document loading, and chain creation. LangChain makes it easy to build complex AI "
        "applications by providing reusable components and patterns.",
        
        "PostgreSQL with pgvector is a powerful vector database solution. It allows you to store "
        "and query high-dimensional vectors efficiently, making it perfect for AI and machine "
        "learning applications. The pgvector extension adds vector similarity search capabilities "
        "to PostgreSQL, enabling fast nearest neighbor searches.",
        
        "Ollama is a tool that allows you to run large language models locally. It provides "
        "an easy way to run, manage and customize different LLM models on your local machine. "
        "With Ollama, you can run AI models without relying on cloud services, ensuring privacy "
        "and reducing costs.",
    ]
    
    num_chunks = rag.add_documents(sample_texts)
    print(f"Added {num_chunks} document chunks to the vector store")
    
    # Example queries
    questions = [
        "What is LangChain and what does it do?",
        "How does PostgreSQL with pgvector help in AI applications?",
        "Can you explain what Ollama is used for?"
    ]
    
    for question in questions:
        print(f"\nQuestion: {question}")
        answer = rag.query(question)
        print(f"Answer: {answer}")

if __name__ == "__main__":
    main()